import discord
from discord.ext import commands
import os
#from model import get_class

description = 'just description'

intents = discord.Intents.default()
intents.members = True
intents.message_content = True

bot = commands.Bot(command_prefix='!', description=description, intents=intents)


@bot.event
async def on_ready():
    print(f'We have logged in as {bot.user} (ID: {bot.user.id})\n----------')


@bot.command()
async def image(ctx):
    if ctx.message.attachments:
        for attachment in ctx.message.attachments:
            if attachment.filename.endswith(".jpg") or attachment.filename.endswith(".jpeg") or attachment.filename.endswith(".png"):
                file_name = f'D:\Other\{attachment.filename}'
                await attachment.save(file_name)
                await ctx.send("Файл принят и загружен")
                pass
                os.remove(file_name)
            else:
                await ctx.send("Файл должен быть поддержиемого формата: .jpg, .jpeg или .png")
                return
    else:
        await ctx.send("Вам надо прикрепить изображение к сообщению.")

bot.run("MTE0NDk2MDIwNjM1NTMwMDM4Mg.GA3dWw.aLSnDiKE1GuH8vmPiN2LZ9cViNS_Qdg60uWrzw")
